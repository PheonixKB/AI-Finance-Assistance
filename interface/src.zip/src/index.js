import ReactDOM from "react-dom/client";
import AppWrapper from "./App";

const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(<AppWrapper />);
